package tests

import game.enemyai.{AIGameState, AIPlayer, PlayerLocation}
import game.lo4_data_structures.linkedlist.LinkedListNode
import game.maps.GridLocation
import org.scalatest._


class Task3 extends FunSuite {
  test("test 1") {
    val newGameState: AIGameState = new AIGameState
    val newVal:AIPlayer = new AIPlayer("template")
    newGameState.levelWidth = 6
    newGameState.levelHeight = 6
    //newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(4.0,2.0,"firstplayer"),null)//slides
    //newGameState.playerLocations= new LinkedListNode[PlayerLocation](new PlayerLocation(2.0,3.0,"secondplayer"), newGameState.playerLocations)
    //newGameState.playerLocations= new LinkedListNode[PlayerLocation](new PlayerLocation(3.0,4.0,"thirdplayer"), newGameState.playerLocations)
    newGameState.wallLocations =List(new GridLocation(1,2),new GridLocation(3,3),new GridLocation(4,5))

    val computedOutcome = newVal.distanceAvoidWalls(newGameState,new GridLocation(1,1),new GridLocation(1,3))

    assert(computedOutcome==4)
  }
}
