package tests
import game.enemyai.{AIGameState, AIPlayer, PlayerLocation}
import game.lo4_data_structures.linkedlist.LinkedListNode
import game.maps.GridLocation
import org.scalatest._


class ApplicationObjective extends FunSuite {
  test("test 1") {
    val newGameState: AIGameState = new AIGameState
    val newVal: AIPlayer = new AIPlayer("template")
    newGameState.levelWidth = 6
    newGameState.levelHeight = 6
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(4.0, 2.0, "firstplayer"), null) //slides
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(2.0, 3.0, "secondplayer"), newGameState.playerLocations)
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(3.0, 4.0, "template"), newGameState.playerLocations)
    //newGameState.playerLocations= new LinkedListNode[PlayerLocation](new PlayerLocation(3.0,4.0,"thirdplayer"), newGameState.playerLocations)
    newGameState.wallLocations = List(new GridLocation(1, 2), new GridLocation(3, 3), new GridLocation(4, 5))
    val computedOutcome = newVal.closestPlayerAvoidWalls(newGameState)
    val expectedOutcome: PlayerLocation = new PlayerLocation(2.0, 3.0, "secondplayer")

    assert(computedOutcome.x == expectedOutcome.x)
    assert(computedOutcome.y == expectedOutcome.y)
    assert(computedOutcome.playerId == expectedOutcome.playerId)


  }
  test("test 2") {
    val newGameState: AIGameState = new AIGameState
    val newVal: AIPlayer = new AIPlayer("template")
    newGameState.levelWidth = 6
    newGameState.levelHeight = 6
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(4.0, 2.0, "firstplayer"), null) //slides
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(1.0, 3.0, "secondplayer"), newGameState.playerLocations)
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(3.0, 4.0, "template"), newGameState.playerLocations)
    //newGameState.playerLocations= new LinkedListNode[PlayerLocation](new PlayerLocation(3.0,4.0,"thirdplayer"), newGameState.playerLocations)
    newGameState.wallLocations = List(new GridLocation(2, 4), new GridLocation(3, 3), new GridLocation(4,4))
    val computedOutcome = newVal.closestPlayerAvoidWalls(newGameState)
    val expectedOutcome: PlayerLocation = new PlayerLocation(1.0, 3.0, "secondplayer")

    assert(computedOutcome.x == expectedOutcome.x)
    assert(computedOutcome.y == expectedOutcome.y)
    assert(computedOutcome.playerId == expectedOutcome.playerId)


  }
  test("test 3") {
    val newGameState: AIGameState = new AIGameState
    val newVal: AIPlayer = new AIPlayer("template")
    newGameState.levelWidth = 6
    newGameState.levelHeight = 6
    newGameState.wallLocations = List(new GridLocation(1, 2), new GridLocation(3, 3), new GridLocation(4, 5))
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(4.0, 2.0, "firstplayer"), null) //slides
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(2.0, 3.0, "secondplayer"), newGameState.playerLocations)
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(3.0, 4.0, "template"), newGameState.playerLocations)
    val startGridLoc: GridLocation = new GridLocation(3,4)
    val endGridLoc: GridLocation = new GridLocation(2, 2)
    val computedOutcome = newVal.getPath(newGameState)
    val expectedOutcome:LinkedListNode[GridLocation]= new LinkedListNode[GridLocation](new GridLocation(1,3),null)
    expectedOutcome.next = new LinkedListNode[GridLocation](new GridLocation(1,2),null)
    expectedOutcome.next.next = new LinkedListNode[GridLocation](new GridLocation(2,2),null)

    assert(startGridLoc.x == computedOutcome.value.x)
    assert(startGridLoc.y == computedOutcome.value.y)
    assert(endGridLoc.x == computedOutcome.next.next.value.x)
    assert(endGridLoc.y == computedOutcome.next.next.value.x)
    assert(computedOutcome.size==3 )
  }



  /*test("test 4") {
    val newGameState: AIGameState = new AIGameState
    val newVal: AIPlayer = new AIPlayer("template")
    newGameState.levelWidth = 3
    newGameState.levelHeight = 3
    newGameState.wallLocations = List(new GridLocation(1, 0), new GridLocation(1, 2))
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(0.0, 2.0, "firstplayer"), null) //slides
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(2.0, 1.0, "secondplayer"), newGameState.playerLocations)
    newGameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(0.0, 0.0, "template"), newGameState.playerLocations)
    val startGridLoc: GridLocation = new GridLocation(0,0)
    val endGridLoc: GridLocation = new GridLocation(2, 2)
    val computedOutcome = newVal.getPath(newGameState)
    val expectedOutcome:LinkedListNode[GridLocation]= new LinkedListNode[GridLocation](new GridLocation(0,0),null)
    expectedOutcome.next = new LinkedListNode[GridLocation](new GridLocation(0,1),null)
    expectedOutcome.next.next = new LinkedListNode[GridLocation](new GridLocation(1,1),null)
    expectedOutcome.next.next.next = new LinkedListNode[GridLocation](new GridLocation(1,2),null)
    expectedOutcome.next.next.next.next = new LinkedListNode[GridLocation](new GridLocation(2,2),null)

    assert(startGridLoc.x == computedOutcome.value.x)
    assert(startGridLoc.y == computedOutcome.value.y)
    assert(endGridLoc.x == computedOutcome.next.value.x)
    assert(endGridLoc.y == computedOutcome.next.value.y)
    assert(computedOutcome.size==4 )
  }
*/

}
