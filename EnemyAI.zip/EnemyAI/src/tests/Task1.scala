package tests

import game.enemyai.{AIGameState, AIPlayer, PlayerLocation}
import game.lo4_data_structures.linkedlist.LinkedListNode
import game.maps.GridLocation
import org.scalatest._

class Task1 extends FunSuite {


  test("test 1") {
  //test if the start and endpoints are the same
    //code can handle negative numbers.cant_move_path_in_negative_directions
    val newVal:AIPlayer = new AIPlayer("template")
    //val aPlayer:PlayerLocation = new PlayerLocation(3.0,5.0,"firstplayer" )
    var listOfPlayers =  new LinkedListNode(new PlayerLocation(3.0,5.0,"firstplayer"),null)//slides
    listOfPlayers= new LinkedListNode[PlayerLocation](new PlayerLocation(4.0,6.0,"secondplayer"), listOfPlayers)
    val computedOutcome = newVal.locatePlayer("firstplayer",listOfPlayers)
    //check x
    assert(computedOutcome.x == listOfPlayers.next.value.x)
    //check y
    assert(computedOutcome.y == listOfPlayers.next.value.y)
    //check id
    assert(computedOutcome.playerId == listOfPlayers.next.value.playerId)
    // TODO

  }


  test("test 2") {
    // compare the location of the players and return the closest one
    //code check that the closest player isn't the same player you're calling the method on
    val newVal: AIPlayer = new AIPlayer("template")
    //val aList:LinkedListNode[GridLocation] = newVal.computePath(new GridLocation(1,3),new GridLocation(2,2))
    val startGridLoc: GridLocation = new GridLocation(1, 3)
    val endGridLoc: GridLocation = new GridLocation(2, 2)
    //val aList =  new LinkedListNode(new PlayerLocation(1.0,3.0,"hi"),null)
    val computedOutcome = newVal.computePath(startGridLoc, endGridLoc)
    val expectedOutcome:LinkedListNode[GridLocation]= new LinkedListNode[GridLocation](new GridLocation(1,3),null)
    expectedOutcome.next = new LinkedListNode[GridLocation](new GridLocation(1,2),null)
    expectedOutcome.next.next = new LinkedListNode[GridLocation](new GridLocation(2,2),null)


      //check start is actually the start
    assert(startGridLoc.x == computedOutcome.value.x)
    //check end is actually the end
    assert(startGridLoc.y == computedOutcome.value.y)
    assert(endGridLoc.x == computedOutcome.next.next.value.x)
    assert(endGridLoc.y == computedOutcome.next.next.value.x)
    //check path size
    assert(computedOutcome.size== 3) //slides



    assert(computedOutcome.value==expectedOutcome.value)
    //assert(computedOutcome.next.value==expectedOutcome.next.value)
    assert(computedOutcome.next.next.value==expectedOutcome.next.next.value)
    //checking for valid steps ( can not exceed 1 or 0)

  }



  test("test 3"){
    val newVal:AIPlayer = new AIPlayer("secondplayer")
    var listOfPlayers =  new LinkedListNode(new PlayerLocation(3.0,5.0,"firstplayer"),null)//slides
    listOfPlayers= new LinkedListNode[PlayerLocation](new PlayerLocation(4.0,6.0,"secondplayer"), listOfPlayers)
    listOfPlayers= new LinkedListNode[PlayerLocation](new PlayerLocation(2.0,4.0,"thirdplayer"), listOfPlayers)
    val computedOutcome = newVal.closestPlayer(listOfPlayers)
    //val aiLoc=newVal.locatePlayer("template",listOfPlayers)
    //println()
    //check x
    assert(computedOutcome.x == listOfPlayers.next.next.value.x)
    //check y
    assert(computedOutcome.y == listOfPlayers.next.next.value.y)
    //check id
    assert(computedOutcome.playerId == listOfPlayers.next.next.value.playerId)


  }


}
