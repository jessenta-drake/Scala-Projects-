package game.enemyai

import akka.util.Helpers.Requiring
import game.enemyai.decisiontree.DecisionTreeValue
import game.enemyai.AIGameState
import game.lo4_data_structures.graphs.Graph
import game.lo4_data_structures.linkedlist._

import game.lo4_data_structures.trees.BinaryTreeNode
import game.maps.GridLocation
import game.{AIAction, MovePlayer}

import scala.math.Ordered.orderingToOrdered

class AIPlayer(val id: String) {


  // TODO: Replace this placeholder code with your own
  def locatePlayer(playerId: String, playerLocations: LinkedListNode[PlayerLocation]): PlayerLocation = {
    //recursion
    findIt(playerId,playerLocations)
  }

    def findIt( x:String, findLocation:LinkedListNode[PlayerLocation]):PlayerLocation= {
      if (findLocation.value.playerId == x) {
        findLocation.value
      }
      else if(findLocation.next == null){
        val emptyThing:PlayerLocation= new PlayerLocation(0,0,"hi")
        emptyThing
      }
      else {
        findIt(x,findLocation.next)
      }
    }



  // TODO: Replace this placeholder code with your own

  def closestPlayer(playerLocations: LinkedListNode[PlayerLocation]): PlayerLocation = {
  //euclideanDistance = Mathsqrt(((this.value.x - playerLocations.value.x)*(this.value.x - playerLocations.value.x))+ ((this.value.y -playerLocations.value.y)*(this.value.y -playerLocations.value.y)))
  //sqrt((x1-x2)^2+(y1-y2)^2)
  //recursion
  //val closestDistance:Double=0.0
  val theAI=locatePlayer(id,playerLocations)
  returningLocation(theAI,999999999.0,playerLocations:LinkedListNode[PlayerLocation])
  }

  def euclideanDistance( firstPlayerLoc:PlayerLocation,secondPlayerLoc:PlayerLocation):Double ={
    val firstDistance = Math.sqrt(((firstPlayerLoc.value.x - secondPlayerLoc.value.x) * (firstPlayerLoc.value.x - secondPlayerLoc.value.x))+((firstPlayerLoc.value.y-secondPlayerLoc.value.y)*(firstPlayerLoc.value.y-secondPlayerLoc.value.y)))
    firstDistance
  }

  def returningLocation (newPlayer:PlayerLocation,initialVal:Double,closestPlayer: LinkedListNode[PlayerLocation] ): PlayerLocation = {
    //iterate through the list
    //AI player get the location
    //val closestDistance:Double=999999999.0
    var comparingDistance = euclideanDistance(closestPlayer.value, newPlayer)
    var newNUmber: Double = initialVal
    var foundPlayer: PlayerLocation = closestPlayer.value
    var newClosestPlayer: LinkedListNode[PlayerLocation] = closestPlayer
    while (newClosestPlayer != null) {
      comparingDistance = euclideanDistance(newClosestPlayer.value, newPlayer)
      if (comparingDistance < newNUmber && newClosestPlayer.value.playerId != newPlayer.playerId) {
        newNUmber = comparingDistance
        foundPlayer = newClosestPlayer.value
      }
      newClosestPlayer = newClosestPlayer.next
    }
    foundPlayer
  }


    // TODO: Replace this placeholder code with your own
    def computePath(start: GridLocation, end: GridLocation): LinkedListNode[GridLocation] = {
      var moreMap: LinkedListNode[GridLocation]=new LinkedListNode[GridLocation](start, null)
      val theMap= moreMap
      //moreMap= new LinkedListNode[GridLocation](end , moreMap)
      var updateA:Int=start.x
      var updateMore: Int = start.y
      while ((moreMap.value.x != end.x) || (moreMap.value.y != end.y)) {
        if (moreMap.value.x < end.x) {
          updateA = updateA + 1
          moreMap.next= new LinkedListNode[GridLocation](new GridLocation(updateA, moreMap.value.y),moreMap)
          moreMap=moreMap.next
        }
        else if (moreMap.value.x > end.x) {
          updateA = updateA - 1
          moreMap.next= new LinkedListNode[GridLocation](new GridLocation(updateA, moreMap.value.y),moreMap)
          moreMap=moreMap.next
        }
        else if (moreMap.value.y < end.y) {
          updateMore= updateMore + 1
          moreMap.next = new LinkedListNode[GridLocation](new GridLocation(updateA, updateMore),moreMap)
          moreMap=moreMap.next
        }
        else if (moreMap.value.y > end.y) {
          updateMore = updateMore - 1
          moreMap.next= new LinkedListNode[GridLocation](new GridLocation(updateA, updateMore),moreMap)
          moreMap=moreMap.next
        }
      

      }

      moreMap.next= new LinkedListNode[GridLocation](end,null)
      moreMap.next=null
      theMap
    }





    // TODO: Replace this placeholder code with your own
    def makeDecision(gameState: AIGameState, decisionTree: BinaryTreeNode[DecisionTreeValue]): AIAction = {
      helperFunction(gameState,decisionTree)
    }
      //MovePlayer(this.id, Math.random() - 0.5, Math.random() - 0.5)
    def helperFunction(gameOfStates: AIGameState, decisionOfTrees: BinaryTreeNode[DecisionTreeValue]): AIAction = {
    val bark: Int = decisionOfTrees.value.check(gameOfStates)
    if (bark < 0) {
      helperFunction(gameOfStates,decisionOfTrees.left)
        }
    else if (bark > 0) {
      helperFunction(gameOfStates,decisionOfTrees.right)
        }
    else {
      decisionOfTrees.value.action(gameOfStates)
        }
      }



    // TODO: Replace this placeholder code with your own
 def closestPlayerAvoidWalls(gameState: AIGameState): PlayerLocation = {
   //val thePlayer:PlayerLocation=new PlayerLocation(0,0,"hi")
   //thePlayer
   //anotherHelper(gameState,999999999,gameState.playerLocations)
   //val theAI=locatePlayer(id,playerLocations)
   returningLocation(gameState,999999999.0,gameState.playerLocations)
    }

  def returningLocation (hiGame:AIGameState,initialVal:Double,closestPlayer: LinkedListNode[PlayerLocation] ): PlayerLocation = {
    val locAI:PlayerLocation= locatePlayer(id,closestPlayer)
    var comparingDistance = euclideanDistance(closestPlayer.value,locatePlayer(id,closestPlayer) )
    var newNUmber: Double = initialVal
    var foundPlayer: PlayerLocation = closestPlayer.value
    var newClosestPlayer: LinkedListNode[PlayerLocation] = closestPlayer
    while (newClosestPlayer != null) {
      comparingDistance = distanceAvoidWalls(hiGame,new GridLocation(newClosestPlayer.value.x.toInt,newClosestPlayer.value.y.toInt), new GridLocation(locatePlayer(id,closestPlayer).x.toInt,locatePlayer(id,closestPlayer).y.toInt))
      if (comparingDistance < newNUmber && newClosestPlayer.value.playerId != locAI.playerId) {
        newNUmber = comparingDistance
        foundPlayer = newClosestPlayer.value
      }
      newClosestPlayer = newClosestPlayer.next
    }
    foundPlayer
  }







/*def anotherHelper(theGameState:AIGameState,initialVal:Int,allPlayers:LinkedListNode[PlayerLocation]):PlayerLocation={
  var smallestOne:Int=999999999
  var thePlayers=allPlayers
  var foundPlayer: PlayerLocation = thePlayers.value
  //val justMapping:Map[Int,PlayerLocation]=Map()
  val locAI:PlayerLocation= locatePlayer(id,allPlayers)
  val aiGridLoc:GridLocation=(new GridLocation((locAI.value.x).toInt,(locAI.value.y).toInt))
  var newDistance: Int = 0
  while (thePlayers != null) {
    val playerGridLoc:GridLocation=(new GridLocation((allPlayers.next.value.x).toInt,(allPlayers.next.value.y).toInt))
    if ((distanceAvoidWalls(theGameState,aiGridLoc,playerGridLoc)<initialVal)&&thePlayers.value.playerId != locAI.playerId) {
      newDistance=distanceAvoidWalls(theGameState,aiGridLoc,playerGridLoc)
      foundPlayer=thePlayers.value
       //justMapping+=newDistance->allPlayers.next.value
      }
    thePlayers=thePlayers.next
    }
    //for (x <- justMapping.keys){
      //if (x<smallestOne){
        //smallestOne=x
      //}
    //}
//val blah = justMapping(smallestOne)
  foundPlayer
  }

*/


    // TODO: Replace this placeholder code with your own
 def getPath(gameState: AIGameState): LinkedListNode[GridLocation] = {
   myHelpee(gameState,(locatePlayer(this.id, gameState.playerLocations).asGridLocation()), (closestPlayerAvoidWalls(gameState).asGridLocation()))
    }
  def myHelpee(theGameState:AIGameState,start:GridLocation,end:GridLocation): LinkedListNode[GridLocation]= {
    var thePath: LinkedListNode[GridLocation] = new LinkedListNode[GridLocation](end, null)
    val withWalls: Graph[GridLocation] = theGameState.levelAsGraph()
    val gridID: GridLocation => Int = start => start.x + start.y * theGameState.levelWidth
    //    def gridID (loc:GridLocation): Int = {
    //      //withwall.nodes key that matches loc and a val
    //      for((k,v) <- withWalls.nodes){
    //        if(v == loc){
    //          return k
    //        }
    //      }
    //      -1
    //    }
    //val theStart:Int=gridID(start)
    //val mappingDistance: Map[Int, Int] = Map(theStart->0)
    var mappingNeighbors: Map[Int, Int] = Map()
    val startID = gridID(start)
    val theQueue: Queue[Int] = new Queue[Int]
    theQueue.enqueue(startID)
    var theExplored: Queue[Int] = new Queue[Int]
    theExplored.enqueue(startID)
    while (!theQueue.empty()) {
      val needExp = theQueue.dequeue()

      for (z <- withWalls.adjacencyList(needExp)) {
        if (!theExplored.contains(z)) {
          theQueue.enqueue(z)
          theExplored.enqueue(z)
          //withWalls.nodes=(z->)
          mappingNeighbors += (z -> needExp)
          //theExplored.dequeue()
        }

      }
    }
    while (gridID(thePath.value) != gridID(start)) {
      val newVal=mappingNeighbors(gridID(thePath.value))

      thePath = new LinkedListNode[GridLocation](withWalls.nodes(newVal), thePath)

    }
    thePath
  }



  def distanceAvoidWalls(theGameState:AIGameState,start:GridLocation,end:GridLocation) : Int= {
    //Parameters of type AIGameState, and two GridLocations
    myHelper(theGameState,start,end)
  }
    def myHelper(theGameState:AIGameState,start:GridLocation,end:GridLocation): Int= {
      var theDistance: Int = 0
      val withWalls: Graph[GridLocation] = theGameState.levelAsGraph()
      val theQueue: Queue[Int] = new Queue[Int]
      val gridID: GridLocation => Int = start => start.x + start.y * theGameState.levelWidth
      val theStart:Int=gridID(start)
      var mappingDistance: Map[Int, Int] = Map(theStart -> 0)
      var mappingNeighbors: Map[Int, Int] = Map()
      theQueue.enqueue(gridID(start))
      var theExplored: List[Int] = List(gridID(start))
      while(!theQueue.empty){
        val needExp = theQueue.dequeue()
        for(z <- withWalls.adjacencyList(needExp)){
          if (!theExplored.contains(z)){
            theQueue.enqueue(z)
            theExplored = theExplored :+ z
            mappingNeighbors +=(needExp->z)
            //theDistance+=1
            mappingDistance += (z -> (1 + mappingDistance(needExp)))
            if(z == gridID(end)) {
              theDistance=mappingDistance(z)

            }
          }
        }
      }
theDistance
}

}

