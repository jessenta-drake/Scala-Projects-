package tests

import music.Music.songListToMap
import music.SongRating
import org.scalatest._
import statistics.Statistics
import music.Song

class Task3 extends FunSuite {
  def compareDoubles(double1: Double, double2: Double): Boolean = {
    val episilon: Double = 0.0001
    (double1 - double2).abs <= episilon
  }

  test("test 1") {
    val firstSong: Song = new Song("HUMBLE", "Kendrick Lamar", "tvTRZJ-4EyI", List(new SongRating(5, 3)))
    val updatedRating: Song = firstSong.addRating(new SongRating(3, 3))
    val updatedRatings: Song = updatedRating.addMultipleRatings(List(new SongRating(4, 4), new SongRating(5, 5)))
    //val updatedRatingss: Song = updatedRatings.addRating(new SongRating(5, 5))
    val firstSongUpdated: Song = new Song("HUMBLE", "Kendrick Lamar", "tvTRZJ-4EyI", List(new SongRating(5, 5), (new SongRating(5, 3)), (new SongRating(4, 4)), (new SongRating(3, 3))))

    val comparator: (SongRating, SongRating) => Boolean = (a: SongRating, b: SongRating) => {
      if (a.rating > b.rating) {
        true
      }
      else if (a.rating < b.rating) {
        false
      }
      else {
        if (a.energyLevel > b.energyLevel) {
          true
        }
        else {
          false
        }
      }

    }
    val expectedOutcome = firstSongUpdated.ratings.sortWith(comparator)
    val computedOutcome = updatedRatings.ratings.sortWith(comparator)


    def checkIfTrue(x: SongRating, y: SongRating): Boolean = {
      if (x.rating == y.rating && x.energyLevel == y.energyLevel) {
        true
      }
      else {
        false
      }
    }

    assert(expectedOutcome.length == computedOutcome.length)
    for (x <- expectedOutcome.indices) {
      assert(checkIfTrue(expectedOutcome(x), computedOutcome(x)))
    }

    //    def sortingMethod(listofRatings:List[SongRating]):List[SongRating]={
    //
    //      }

    //      if(comparator == ((a: SongRating, b: SongRating) =>true) {
    //        val comparators: (SongRating, SongRating) => Boolean = (c: SongRating, d: SongRating) => c.energyLevel > d.energyLevel
    //        val updater = listofRatings.sortWith(comparators)
    //        updater
    //      }


    //compare list size
    //sort,function


  }
  test("test 2") {
    val firstSong: Song = new Song("HUMBLE", "Kendrick Lamar", "tvTRZJ-4EyI", List(new SongRating(1, 2)))
    val secondSong: Song = new Song("HUMBLE", "Kendrick Lamar", "tvTRZJ-4EyI", List(new SongRating(2, 4)))
    //val thirdSong: Song = new Song("Lofi Gir", "lofi hip hop", "5qap5aO4i9A", List(new SongRating(2, 1)))
    val listOfSongs: List[Song] = List(firstSong, secondSong)

    //val firstMap: Map[String, Song] = Map("tvTRZJ-4EyI" -> new Song("HUMBLE", "Kendrick Lamar", "tvTRZJ-4EyI", List(new SongRating(5, 3), (new SongRating(7, 4)))))
    val combinedSong:Song = new Song("HUMBLE", "Kendrick Lamar", "tvTRZJ-4EyI", List(new SongRating(2, 4), (new SongRating(1, 2))))


    val listToMap: Map[String, Song] = music.Music.songListToMap(listOfSongs)

    val comparator: (SongRating, SongRating) => Boolean = (a: SongRating, b: SongRating) => {
      if (a.rating > b.rating) {
        true
      }
      else if (a.rating < b.rating) {
        false
      }
      else {
        if (a.energyLevel > b.energyLevel) {
          true
        }
        else {
          false
        }
      }

    }
    val expectedOutcome = combinedSong.ratings.sortWith(comparator)

    def checkIfTrue(x: SongRating, y: SongRating): Boolean = {
      if (x.rating == y.rating && x.energyLevel == y.energyLevel) {
        true
      }
      else {
        false
      }
    }

    assert((listToMap("tvTRZJ-4EyI").title) == combinedSong.title, "HUMBLE")
    assert((listToMap("tvTRZJ-4EyI").artist) == combinedSong.artist, "Kendrick Lamar")
    assert((listToMap("tvTRZJ-4EyI").youtubeId) == combinedSong.youtubeId, "tvTRZJ-4EyI")
    assert(expectedOutcome.length == (listToMap("tvTRZJ-4EyI").ratings.sortWith(comparator).length))
    val computedOutcome =(listToMap("tvTRZJ-4EyI").ratings.sortWith(comparator))
    for (x <- expectedOutcome.indices) {
      println((expectedOutcome(x).rating), expectedOutcome(x).energyLevel)
      println(computedOutcome(x).rating, listToMap("tvTRZJ-4EyI").ratings.sortWith(comparator)(x).energyLevel)
      println()
      assert(checkIfTrue(expectedOutcome(x), computedOutcome(x)))
    }
    //assert((listToMap("tvTRZJ-4EyI").ratings.sortWith(comparator) == (expectedOutcome)))


    // check rating
    //assert for each one
    //val getvalue = Map("vTRZJ-4EyI")
    }
    //.contain
}
