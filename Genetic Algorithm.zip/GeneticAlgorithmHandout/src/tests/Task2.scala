package tests

import music.Music.{readSongsFromFileWithoutDuplicates, readUserRatingsFromFile}
import music.{Music, SongRating}
import org.scalatest._
import statistics.Statistics
import music.Song



class Task2 extends FunSuite {
  test("test 1") {
    println(readUserRatingsFromFile("data/song_ratings_2021.csv"))
  }
  test("test 2") {
    println(readSongsFromFileWithoutDuplicates("data/yourRatings.csv"))
    println(readSongsFromFileWithoutDuplicates("data/song_ratings_2021.csv"))
  }
}
