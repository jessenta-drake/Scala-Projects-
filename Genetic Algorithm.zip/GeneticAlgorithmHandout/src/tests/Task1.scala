package tests

import music.{Music, SongRating}
import org.scalatest._
import statistics.Statistics
import music.Song


class Task1 extends FunSuite {
  def compareDoubles(double1: Double, double2: Double): Boolean = {
    val episilon: Double = 0.0001
    (double1 - double2).abs <= episilon
  }

  test("test 1") {
    val firstSong: SongRating = new SongRating(1, 1)
    val secondSong: SongRating = new SongRating(rating = 2, 5)
    val thirdSong: SongRating = new SongRating(rating = 3, 8)
    val fourthSong: SongRating = new SongRating(rating = 4, 9)
    val fifthSong: SongRating = new SongRating(rating = 5, 2)

    val ratings: List[SongRating] = List(firstSong, secondSong, thirdSong, fourthSong, fifthSong)

    val getStuff: SongRating => Double = (rating: SongRating) => (rating.rating)
    val computed: Double = Statistics.average[SongRating](ratings, getStuff)
    val expected: Double = 3.0
    assert(Math.abs(computed - expected) < 0.001)
    //assert(CompareDoubles(computed,expected),"computed"+computed+"expected"+expected)


  }
  test("test 2") {
    val puppies: List[Int] = List(2, 1, 3, 4, 3)
    val cats: Int => Double = (x: Int) => x.toDouble
    val lizards = Statistics.topK[Int](puppies, cats, 3)
    assert(lizards.length == 3)
    assert(compareDoubles(lizards.head, 4))
    assert(compareDoubles(lizards(1), 3))
    assert(compareDoubles(lizards(2), 3))
  }

  test("test 3") {
    val purple: List[Int] = List(4, 3, 2, 1)
    val blue: Int => Double = (x: Int) => x.toDouble
    val green = Statistics.topK[Int](purple, blue, 4)
    assert(green.length == 4)

  }

  test("test 4") {
    val firstSong: SongRating = new SongRating(1, 4)
    val secondSong: SongRating = new SongRating(rating = 2, 6)
    val thirdSong: SongRating = new SongRating(rating = 3, 2)
    //val fourthSong: SongRating = new SongRating(rating = 4, 9)
    //val fifthSong: SongRating = new SongRating(rating = 5, 2)
    val chair: List[SongRating] = List(firstSong, secondSong, thirdSong)
    val stool: SongRating => Double = (x: SongRating) => x.rating
    assert(Statistics.topK[SongRating](chair, stool, 1) == List(chair(2)))

  }
  test("test 5") {
    val puppies: List[Int] = List(2, 1, 3, 4, 3)
    val cats: Int => Double = (x: Int) => x.toDouble
    val lizards = Statistics.topK[Int](puppies, cats, 6)
    assert(lizards == List(4, 3, 3, 2, 1))
  }
  test("test 6") {

    val show: List[Int] = List(1,2,3)
    // val show: List[Int] = List(2,4,6,3,3,3,3,3,3)
    val play: Int => Double = _.toDouble
    val computed: Double = Statistics.bayesianAverage[Int](show, play,4,4)
    val expected: Double = 3.14285714
    assert(Math.abs(computed - expected) < 0.001)
    assert(compareDoubles(computed,expected),"computed"+computed+"expected"+expected)


  }
  test("test 7") {
    val firstSong: SongRating = new SongRating(1, 4)
    val secondSong: SongRating = new SongRating(rating = 2, 6)
    val thirdSong: SongRating = new SongRating(rating = 3, 2)

    //val fourthSong: SongRating = new SongRating(rating = 4, 9)
    //val fifthSong: SongRating = new SongRating(rating = 5, 2)
    val carnival: List[SongRating] = List(firstSong, secondSong, thirdSong)

    val mySong:Song=new Song ("rada","radarada","cottonCandy",carnival)

    val whenRating1:Map[String,Int]=Map("cottonCandy"->1)
    val whenRating2:Map[String,Int]=Map("cottonCandy"->2)
    val whenRating3:Map[String,Int]=Map("cottonCandy"->3)
    val whenRating4:Map[String,Int]=Map("cottonCandy"->4)
    val whenRating5:Map[String,Int]=Map("cottonCandy"->5)
    val whenRatingNull:Map[String,Int]=Map("noCottonCandy"->3)



    val whenIts1:Song => Double = Music.songCostFunction(whenRating1)
    val whenIts2:Song => Double = Music.songCostFunction(whenRating2)
    val whenIts3:Song => Double = Music.songCostFunction(whenRating3)
    val whenIts4:Song => Double = Music.songCostFunction(whenRating4)
    val whenIts5:Song => Double = Music.songCostFunction(whenRating5)
    val whenItsNull:Song => Double = Music.songCostFunction(whenRatingNull)

    assert(compareDoubles(1000.0,whenIts1(mySong)))
    assert(compareDoubles(1000.0,whenIts2(mySong)))
    assert(compareDoubles(0.13888889,whenIts3(mySong)))
    assert(compareDoubles(0.10416667,whenIts4(mySong)))
    assert(compareDoubles(0.08333333,whenIts5(mySong)))
    assert(compareDoubles(0.13888889,whenItsNull(mySong)))




    //val getStuff: SongRating => Double = (rating: SongRating) => (rating.rating)
    //val computed: Song =>Double = Music.songCostFunction(Map("cottonCandy"->1))
    //val expected: Double = 1000.0
    //assert(Math.abs(computed - expected) < 0.001)
    //assert(compareDoubles((computed,expected),"computed"+computed+"expected"+expected)


  }
  test("test 8") {
    val firstSong: SongRating = new SongRating(1, 4)
    val secondSong: SongRating = new SongRating(rating = 2, 6)
    val thirdSong: SongRating = new SongRating(rating = 3, 2)


    val carnival: List[SongRating] = List(firstSong, secondSong, thirdSong)

    val mySong:Song=new Song ("rada","radarada","cottonCandy",carnival)

    val whenRating1:Map[String,Int]=Map("cottonCandy"->1)




    val whenIts1:Song => Double = Music.songCostFunction(whenRating1)

    assert(compareDoubles(1000.0,whenIts1(mySong)))







  }
}

