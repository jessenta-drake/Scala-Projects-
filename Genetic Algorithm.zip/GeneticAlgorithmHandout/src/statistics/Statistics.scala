package statistics

object Statistics {
  def average[T](data: List[T], f: T => Double): Double = {

    val total: Double = data.map(f).sum
    val theDivisor: Int = data.map(f).length
    val theAvg: Double = total / theDivisor
    theAvg


    //var summ: Double = 0
    //val function = (a: Double) => {summ += a}
    //data.foreach(summ += _)
    // TODO
  }

  def topK[T](something: List[T], d: T => Double, k: Int): List[T] = {

    //A list of doubles
    //val convert: List[Double] = something.map(d)
    //sort through the list
    //slice function
    //missing something

    val orderedList = something.sortBy(d).reverse
    val pickedSongs: List[T] = orderedList.slice(0, k)
    pickedSongs

  }

  def bayesianAverage[T](coolBeans: List[T], j: T => Double, numFakeRating: Int, extraFakeRatings: Int): Double = {
    // loop,recursion,helper make list, find avg
    val total:List[Double]=coolBeans.map(j)
    helper(numFakeRating,extraFakeRatings,total)

    }
  def helper(x: Int,y:Int,z:List[Double]): Double={
    if (x <= 0) {
      average(z,(r:Double)=>r)
    }
    else {
      helper(x-1,y,y::z)
  }



  }


}
