package music

import music.Music._


import scala.io.Source
import music.Song
object Music {


  // TODO: Implement required methods as defined in the HW Doc


  /**
   * You may use this helper method to read a file and return a List of Strings containing the lines of the file
   *
   * @param filename The file to be read
   * @return The lines of the file as a List of Strings with 1 String per line
   */
  def filenameToListOfLines(filename: String): List[String] = {
    val file = Source.fromFile(filename)
    val lines: List[String] = file.getLines().toList
    file.close()
    lines
  }

  // TODO: Uncomment after implementing the required methods
  // Uses your methods to read all the data in a file with song ratings
  /*def readSongsFromFile(filename: String): List[Song] = {
      val songsWithDuplicates: List[Song] = readSongsFromFileWithoutDuplicates(filename)
      val songMap: Map[String, Song] = songListToMap(songsWithDuplicates)
      songMap.values.toList
    }
    */


  // Can be used to test your application objective
  def songIncubator(songs: List[Song]): List[Double] => Song = {
    genes: List[Double] => {
      val geneSong: Int = (genes.head.abs * songs.length).toInt % songs.length
      songs(geneSong)
    }
  }

  // Can be used to test your application objective
  def playlistIncubator(songs: List[Song]): List[Double] => Playlist = {
    genes: List[Double] => {
      val incubatorForSongs: List[Double] => Song = songIncubator(songs)
      new Playlist(genes.map((gene: Double) => incubatorForSongs(List(gene))))
    }
  }

  def songCostFunction(usersRating: Map[String, Int]): Song => Double = {
    (x: Song) => {
      val bye = x.bayesianRating(2, 3)
      val hello = usersRating.getOrElse(x.youtubeId, 3)
      if (hello <= 2) {
        1000.0
      }
      else {
        1 / (bye * hello)
      }

    }
  }

  def readUserRatingsFromFile(fileName: String): Map[String, Int] = {
    //(blah: Song) => {
    //recursion
    //getlines
    //read the file
    // getlines
    //split at the comma
    // next()
    //val newMap: Map[String, Int] = Map()

    val readingfile = Source.fromFile(fileName)
    //myHelper(readingfile.getLines(),Map())
    val changedToList = readingfile.getLines().toList
    myHelper(changedToList, Map())
    //val splitUp = line.split(",")
    //if (splitUp(1) =)
    //}

    //}
  }

  def myHelper(y: List[String], newMap: Map[String, Int]): Map[String, Int] = {

    if (y.isEmpty) {
      newMap
      //if the first value after splitting equals the youtube id map the id to the rating
      //do I need a value for youtube id?

    }

    else {
      val updatedList = y.head.split(",")
      myHelper(y.drop(1), newMap + (updatedList.head -> updatedList(3).toInt))
    }
  }


  def readSongsFromFileWithoutDuplicates(filerName: String): List[Song] = {
    val readingfiles = Source.fromFile(filerName)
    val changedToLists = readingfiles.getLines().toList
    myHelpers(List(), changedToLists)
  }

  def myHelpers(newList: List[Song], b: List[String]): List[Song] = {

    if (b.isEmpty) {
      newList
    }
    else {
      //split
      val updatedList = b.head.split(",")
      //empty list
      //val listOfRatings:List[SongRating]=List()
      //make a list of song ratings with of 3 and 4
      //listOfRatings :+ updatedList(3)
      //listOfRatings :+ updatedList(4)
      //myHelpers(b.drop(1), newList :+ new Song (updatedList.head,updatedList(1),updatedList(2),listOfRatings.distinct))
      myHelpers(new Song(updatedList(2), updatedList(1), updatedList(0), List(new SongRating(updatedList(3).toInt, updatedList(4).toInt))) :: newList, b.drop(1))
      //i dont thing its putting the ratings in a list
      //songobject to the end of list line)


    }

  }

  def songListToMap(aList: List[Song]): Map[String, Song] = {
    //aList=readSongsFromFileWithoutDuplicates(filerName).distinct
    myHelperss(aList, Map())
  }

  def myHelperss(y: List[Song], newMap: Map[String, Song]): Map[String,Song] = {

    if (y.isEmpty) {
      newMap
    }
    else {

      val myYoutubeId = y.head.youtubeId
      val returnedSong:Song = y.head
      //how to add the duplicates of the same youtubeId
      if( newMap contains myYoutubeId){
        //get song from newmap
        val getMySong:Song = newMap(myYoutubeId)
        //get the list of ratings
        val listFromSong:List[SongRating]=getMySong.ratings
        //returned songs . add multiple ratings (val)
          val changedIt =getMySong.addMultipleRatings(y.head.ratings)
        myHelperss(y.drop(1), newMap + (myYoutubeId -> changedIt))
      }
      else
      {
        myHelperss(y.drop(1), newMap + (myYoutubeId -> returnedSong))
      }

      //do i need this helper if I already have one for maps
    }
  }
}










