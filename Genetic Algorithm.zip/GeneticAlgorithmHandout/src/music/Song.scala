package music

import statistics.Statistics

class Song(val title: String, val artist: String, val youtubeId: String, val ratings: List[SongRating]) {

  def averageRating(): Double = {
    // This is an example of calling your average function to get the average rating of a song
    Statistics.average(this.ratings, (rating: SongRating) => rating.rating)
  }

  def averageEnergyRating(): Double = {
    // This is an example of calling your average function to get the average energy rating of a song
    Statistics.average(this.ratings, (rating: SongRating) => rating.energyLevel)
  }

  // TODO: Uncomment this method after writing Statistics.bayesianAverage
  // Compute the bayesian average of song ratings
 def bayesianRating(extraRatings: Int, valueOfExtraRatings: Int): Double = {
   Statistics.bayesianAverage(this.ratings, (rating: SongRating) => rating.rating, extraRatings, valueOfExtraRatings)
  }

  def addRating(x:SongRating): Song ={
    val moreRatings=this.ratings:+x
    val updateSong:Song= new Song (title,artist,youtubeId,moreRatings)
    updateSong
  }

  def addMultipleRatings(x:List[SongRating]):Song={
    val addMultiple:List[SongRating]=this.ratings++x// When adding two list together use ++
    val updateSongg:Song =new Song (title,artist,youtubeId,addMultiple)
    updateSongg
  }



}


