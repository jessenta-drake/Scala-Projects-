package tests

import org.scalatest._
import pbd.PaleBlueDot

class Task3 extends FunSuite {

  val countriesFile: String = "data/countries.txt"
  val citiesFilename: String = "data/cities.csv"

  val epsilon: Double = 0.0001

  def compareDoubles(d1: Double, d2: Double): Boolean = {
    Math.abs(d1 - d2) < epsilon
  }


   test("test 1") {
    val testCases: List[String] = List(
      "les escaldes"

    )

      val computedOutput= PaleBlueDot.aboveAverageCities(countriesFile, citiesFilename,"Andorra")
      assert(computedOutput.sorted == testCases.sorted)

  }



  test("test 2") {
    val Cases: List[String] = List(
      "aden","ibb"

    )

    val computedOutput= PaleBlueDot.aboveAverageCities(countriesFile, citiesFilename,"Yemen")
    assert(computedOutput.sorted == Cases.sorted)

  }

  test("test 3") {
    val Cases: List[String] = List(


    )

    val computedOutput= PaleBlueDot.aboveAverageCities(countriesFile, citiesFilename,"Anguilla")
    assert(computedOutput.sorted == Cases.sorted)

  }





  test(testName = "test 4"){
    val newTest:Map[String,Int] =Map(
      "la massana" -> 7211,
      "les escaldes" -> 15854,
      "ordino" -> 2553,
      "sant julia de loria" -> 8020
    )

    val computedOutput= PaleBlueDot.cityPopulations(countriesFile, citiesFilename, "Andorra")
    assert(computedOutput == newTest)

  }

}
