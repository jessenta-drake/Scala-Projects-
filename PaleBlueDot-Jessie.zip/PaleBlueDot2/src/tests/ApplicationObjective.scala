package tests

import org.scalatest._
import pbd.PaleBlueDot

class ApplicationObjective extends FunSuite {

  val countriesFile: String = "data/countries.txt"
  val citiesFilename: String = "data/cities.csv"

  test("test 1"){
    val Cases: List[String] = List(
      "56", "es", "igualada"
    )

    val computedOutput= PaleBlueDot.closestCity(citiesFilename,List(41.55,1.4166667))
  }

  test("test 2"){
    val anotherCases: List[String] = List(
      "sj","longyearbyen","00"
    )

    val computedOutput= PaleBlueDot.closestCity(citiesFilename,List(78.1166667,15.5333333))
    assert(computedOutput.sorted == anotherCases.sorted)
  }

  test("test 3"){
    val xCases: List[String] = List(
      "09", "gh", "takoradi"
    )

    val computedOutput= PaleBlueDot.closestCity(citiesFilename,List(0.0,0.0))
    assert(computedOutput.sorted == xCases.sorted)
  }

  test("test 4"){
    val xCases: List[String] = List(
      "NY", "north tonawanda", "us"
    )

    val computedOutput= PaleBlueDot.closestCity(citiesFilename,List(43.002743, -78.7874136))
    assert(computedOutput.sorted == xCases.sorted)
  }

  test("test 5"){
    val xCases: List[String] = List(
      "00", "ny-alesund", "sj"
    )

    val computedOutput= PaleBlueDot.closestCity(citiesFilename,List(90.0, 135.0))
    assert(computedOutput.sorted == xCases.sorted)
  }

  test("test 6") {
    val xCases: List[String] = List(
      "00", "ny-alesund", "sj"
    )

    val computedOutput = PaleBlueDot.closestCity(citiesFilename, List(90.0, 45.0))
    assert(computedOutput.sorted == xCases.sorted)


  }
  test("test 7") {
    val xCases: List[String] = List(
      "us","barrow","AK"
    )

    val computedOutput = PaleBlueDot.closestCity(citiesFilename, List(84.94, 176.9))
    assert(computedOutput.sorted == xCases.sorted)


  }
}
