package tests

import org.scalatest._
import pbd.PaleBlueDot

import scala.math.Equiv

class Task2 extends FunSuite {

  val countriesFile: String = "data/countries.txt"
  val citiesFile: String = "data/cities.csv"

  val epsilon: Double = 0.0001

  def compareDoubles(d1: Double, d2: Double): Boolean = {
    Math.abs(d1 - d2) < epsilon
  }
  test("2 - testing") {
    val testCases: Map[String, Double] = Map(
      "Andorra" -> 8409.5,
      "ArUba"->29998.0
    )
    for ((input, expectedOutput) <- testCases) {
      val computedOutput: Double = PaleBlueDot.averagePopulation(countriesFile, citiesFile, input)
      assert(compareDoubles(expectedOutput,computedOutput),"expectedOutput"+expectedOutput+"computedOutput"+computedOutput)
    }
  }
}