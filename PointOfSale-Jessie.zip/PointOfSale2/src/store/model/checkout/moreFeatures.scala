package store.model.checkout

abstract class moreFeatures (x:SelfCheckout){
  def enterPressed(): Unit
  def displayString(): String
  def clearPressed(): Unit
  def numberPressed(x:Int):Unit
  def cashPressed(): Unit
  def creditPressed(): Unit
  def loyaltyCardPressed(): Unit
  def checkoutPressed(): Unit

  //everything with Pressed(done)
  //scan,rescan,checkout
}
