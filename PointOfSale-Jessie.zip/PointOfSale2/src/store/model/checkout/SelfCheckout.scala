package store.model.checkout

import store.model.items.{BottleDeposit, Item, LoyaltySale, Modifier, Sale, SalesTax, theFeatures, transitionState}
import store.view.SelfCheckoutGUI

import scala.+:

class SelfCheckout {
var newItem:Map[String,Item]=Map()
var numbers:String=""
var customerCart:List[Item]=List()
var theItem = new Item("",0.0)
var question:String=""
var state: moreFeatures = new Scan(this)

  def addItemToStore(barcode: String, item: Item): Unit = {
    newItem=newItem+(barcode -> item)
  }

  def numberPressed(number: Int): Unit = {
    //numbers += number.toString
    this.state.numberPressed(number)
    // TODO
  }

  def clearPressed(): Unit = {
    //numbers = ""
    this.state.clearPressed()
    // TODO
  }

  def enterPressed(): Unit = {
    //val obj =new Item("error",0.0)
    //this.customerCart =  customerCart :+ newItem.getOrElse(numbers,obj)
    //numbers=""
    this.state.enterPressed()
    // TODO
  }

  def checkoutPressed(): Unit = {
    this.state.checkoutPressed()
    // TODO
  }

  def cashPressed(): Unit = {
    this.state.cashPressed()
    // TODO
  }

  def creditPressed(): Unit = {
    this.state.creditPressed()
    // TODO
  }

  def loyaltyCardPressed(): Unit = {
    this.state.loyaltyCardPressed()
    // TODO
  }

  def displayString(): String = {
    this.state.displayString()
    // TODO
  }

  def itemsInCart(): List[Item] = {
   customerCart
   //TODO
  }

  def subtotal(): Double = {
    var newTotalOfItems:Double=0.0
    for(theItem<-customerCart){
      newTotalOfItems += theItem.price()
    }
    newTotalOfItems
  }

  def tax(): Double = {
    var newTotalOfTax:Double=0.0
    for(theItem<-customerCart){
      newTotalOfTax += theItem.tax()
    }
    newTotalOfTax
    }


  def total(): Double = {
    subtotal()+tax()


  }

  def prepareStore(): Unit = {
    // Similar to openMap in the Pale Blue Dot assignment, this method is not required and is
    // meant to help you run manual tests.
    //
    // This method is called by the GUI during setup. Use this method to prepare your
    // items and call addItemToStore to add their barcodes. Also add any sales/tax/etc to your
    // items.
    //
    // This method will not be called during testing and you should not call it in your tests.
    // Each test must setup its own items to ensure compatibility in AutoLab. However, you can
    // write a similar method in your Test Suite classes.

    // Example usage:
    //val testItem: Item = new Item("test item", 100.0)
    //this.addItemToStore("472", testItem)

    val testItem: Item = new Item("banana",1.00)
    this.addItemToStore("123", testItem)
    testItem.addModifier(new LoyaltySale(20))


    val testItem2: Item = new Item("strawberry",2.00)
    this.addItemToStore("234", testItem2)
    testItem2.addModifier(new LoyaltySale(20))

    val testItem3: Item = new Item("mango",3.00)
    this.addItemToStore("345", testItem3)
    testItem3.addModifier(new LoyaltySale(20))

    val testItem4: Item = new Item("kiwi",4.00)
    this.addItemToStore("456", testItem4)
    testItem4.addModifier(new LoyaltySale(20))

    val testItem5: Item = new Item("dragon fruit",5.00)
    this.addItemToStore("567", testItem5)
    testItem5.addModifier(new Sale(20.0))
    testItem5.addModifier(new SalesTax(40.0))
    testItem5.addModifier(new BottleDeposit(2.00))
    testItem5.addModifier(new LoyaltySale(20))

    val testItem6: Item = new Item("apple",6.00)
    this.addItemToStore("678", testItem6)
    testItem6.addModifier(new LoyaltySale(20))

    val testItem7: Item = new Item("orange",7.00)
    this.addItemToStore("789", testItem7)
    testItem7.addModifier(new LoyaltySale(20))

    val testItem8: Item = new Item("lemon",8.00)
    this.addItemToStore("890", testItem8)
    testItem8.addModifier(new LoyaltySale(20))

    val testItem9: Item = new Item("grapes",9.00)
    this.addItemToStore("901", testItem9)
    testItem9.addModifier(new LoyaltySale(20))

    val testItem10: Item = new Item("melon",10.00)
    this.addItemToStore("0012", testItem10)
    testItem10.addModifier(new Sale(10.0))
    testItem10.addModifier(new SalesTax(10.0))
    testItem10.addModifier(new BottleDeposit(1.00))
    testItem10.addModifier(new LoyaltySale(20))

  }

}


