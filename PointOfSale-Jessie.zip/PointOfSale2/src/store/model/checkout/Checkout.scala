package store.model.checkout

import store.model.items.{Item, LoyaltySale, offState, transitionState}

class Checkout(x:SelfCheckout) extends moreFeatures(x) {

  def numberPressed(number: Int): Unit = {
    //x.state= new Scan(x:SelfCheckout)
    // TODO
  }
  def clearPressed(): Unit = {
    //x.state= new Scan(x:SelfCheckout)
    // TODO
  }

  def enterPressed(): Unit = {
    //x.state= new Scan(x:SelfCheckout)

    // TODO
  }

  def checkoutPressed(): Unit = {
    //x.state= new Scan(x:SelfCheckout)
  }

  def cashPressed(): Unit = {
//set to empty list
    x.customerCart=List()
    x.numbers=""
    x.state=new Scan(x:SelfCheckout)

    val theValues=x.newItem.values
    for(y<-theValues){
      //y.togetherIG=List()
     for(m <- y.togetherIG){
        m.anotherState= new offState(m)
      }
      //turn all modifiers on

    }


   // x.state=new Scan(x:SelfCheckout)
  }

  def creditPressed(): Unit = {
//set to empty list
    x.customerCart=List()
    x.numbers=""
    val theValues=x.newItem.values
    for(y<-theValues){
      //y.togetherIG=List()
      for(m <- y.togetherIG){
       m.anotherState= new offState(m)
      }
      //turn all modifiers on

    }


    x.state=new Scan(x:SelfCheckout)
  }

  def loyaltyCardPressed(): Unit = {
    val theValues=x.newItem.values
    for(y<-theValues){
      for(m <- y.togetherIG){
        m.anotherState= new transitionState(m)
        //y.togetherIG -= m
      }
      //turn all modifiers on
    }
    //print("checkout loyalty pressed")
    //x.state=new Scan(x:SelfCheckout)
  }

  override def displayString(): String = {
    x.numbers="cash or credit"
    x.numbers


    // TODO
  }

}
