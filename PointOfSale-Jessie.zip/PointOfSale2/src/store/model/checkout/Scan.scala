package store.model.checkout

import store.model.items.{Item, LoyaltySale}
import store.view.SelfCheckoutGUI

class Scan(x:SelfCheckout) extends moreFeatures(x) {
  override def numberPressed(number: Int): Unit = {
    x.numbers += number

    // TODO
  }

  override def clearPressed(): Unit = {
    x.numbers = ""
    // TODO
  }

  override def enterPressed(): Unit = {
    val obj =new Item("error",0.0)
    x.customerCart =  x.customerCart :+ x.newItem.getOrElse(x.numbers,obj)
    //for (someItem<-x.customerCart) {
      //x.customerCart =  x.customerCart :+ someItem
    //}
    x.numbers=""
    x.state=new Rescan(x:SelfCheckout)
    // TODO
  }

  def checkoutPressed(): Unit = {
    x.state=new Checkout(x:SelfCheckout)
    // TODO
  }

  def cashPressed(): Unit = {
    //this.customerCart=List()
    //x.state=new Checkout(x:SelfCheckout)
    // TODO
  }

  def creditPressed(): Unit = {
    //this.customerCart=List()
    //x.state=new Checkout(x:SelfCheckout)
    // TODO
  }

  def loyaltyCardPressed(): Unit = {
    val theValues=x.newItem.values
    for(y<-theValues){
      for(m <- y.togetherIG){
        m.switchStates()
      }
    }

    //switch states
    // TODO
  }

  override def displayString(): String = {

     x.numbers



    // TODO
  }
}
