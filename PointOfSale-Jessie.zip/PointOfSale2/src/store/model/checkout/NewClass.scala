package store.model.checkout

class NewClass extends SelfCheckout {

  println(enterPressed())


}
