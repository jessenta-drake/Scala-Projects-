package store.model.checkout

import store.model.items.{Item, LoyaltySale}

class Rescan(x:SelfCheckout) extends moreFeatures(x) {

  override def enterPressed(): Unit = {
    //val obj =new Item("error",0.0)
    x.customerCart = x.customerCart :+ x.customerCart.last


  }

  override def numberPressed(number: Int): Unit = {
    x.numbers += number.toString
    x.state = new Scan(x: SelfCheckout)
    // TODO
  }

  override def clearPressed(): Unit = {
    x.numbers = ""
    x.state = new Scan(x: SelfCheckout)
    // TODO
  }

  def checkoutPressed(): Unit = {
    x.state = new Checkout(x: SelfCheckout)
    // TODO
  }

  def cashPressed(): Unit = {
    //x.customerCart=List()
    //x.state=new Checkout(x:SelfCheckout)
    //this.customerCart=List()
    // TODO
  }

  def creditPressed(): Unit = {
    //x.customerCart=List()
    //x.state=new Checkout(x:SelfCheckout)
    //this.customerCart=List()
    // TODO
  }

  def loyaltyCardPressed(): Unit = {
    val theValues = x.newItem.values
    for(y<-theValues){
      for(m <- y.togetherIG){
        m.switchStates()
      }
      //turn all modifiers on

    }
      // TODO
    }

    override def displayString(): String = {
      ""
      // TODO
    }
    //def itemsInCart(): List[Item] = {
    //x.customerCart
    //TODO
    //}

}
