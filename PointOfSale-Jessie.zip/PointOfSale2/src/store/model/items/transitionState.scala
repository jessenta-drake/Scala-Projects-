package store.model.items

class transitionState(y:Modifier)extends theFeatures(y){
  //val perPer: Double = percentageOfSale / 100.0
  override def updatePrice(thePrice: Double): Double = {
    val applyTo: Double = (thePrice * (1 - y.perPer))
    applyTo
  }
  override def computeTax(theTax: Double): Double = {
    0.0
  }
  override def switchStates():Unit={
    //y.anotherState = new offState(y:Modifier)
  }
}
