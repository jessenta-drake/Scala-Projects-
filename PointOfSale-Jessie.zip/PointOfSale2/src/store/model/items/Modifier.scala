package store.model.items

abstract class Modifier {
  var anotherState:theFeatures = new offState(this)

  var perPer: Double = 0.0
  def updatePrice(thePrice: Double): Double

  def computeTax(theTax: Double): Double

  def switchStates():Unit
}
