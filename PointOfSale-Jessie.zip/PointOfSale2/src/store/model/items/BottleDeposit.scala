package store.model.items

class BottleDeposit (amountDeposit:Double) extends Modifier{
  //this.anotherState = null
  override def updatePrice(thePrice: Double): Double = {
    thePrice
  }

  override def computeTax(theTax: Double): Double = {
    amountDeposit
  }
  override def switchStates():Unit={

  }


}
