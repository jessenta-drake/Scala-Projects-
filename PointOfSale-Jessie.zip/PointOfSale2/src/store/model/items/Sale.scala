package store.model.items

class Sale (percentageOfSale:Double) extends Modifier {
  //val perPer:Double=percentageOfSale/100.0
  //this.anotherState= null
  override def updatePrice(thePrice: Double): Double = {
    val applyTo:Double=(thePrice*(1-(percentageOfSale/100.0)))
    applyTo
  }

  override def computeTax(theTax: Double): Double = {
    0.0
  }
  override def switchStates():Unit={

  }
}
