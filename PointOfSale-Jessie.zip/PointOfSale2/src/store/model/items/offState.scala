package store.model.items

class offState(y:Modifier) extends theFeatures(y) {
  override def updatePrice(thePrice: Double): Double = {
    thePrice
    }

  override def computeTax(theTax: Double): Double = {
    0.0
  }
  override def switchStates():Unit={
    y.anotherState = new transitionState(y:Modifier)
  }
}
