package store.model.items

class SalesTax (percentageOfSalesTax:Double) extends Modifier {
  //val pertyPert:Double=percentageOfSalesTax/100.0
  //var anotherState:theFeatures = null
  override def updatePrice(thePrice: Double): Double = {
    thePrice
  }

  override def computeTax(theTax: Double): Double = {
    val applyMore:Double=(theTax*(percentageOfSalesTax/100))
    applyMore
  }

  override def switchStates():Unit={

  }
}
