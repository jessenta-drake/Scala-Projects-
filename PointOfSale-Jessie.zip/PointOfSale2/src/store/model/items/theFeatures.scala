package store.model.items

abstract class theFeatures (y:Modifier){
  def updatePrice(thePrice: Double): Double
  def computeTax(theTax: Double): Double
  def switchStates():Unit
}
