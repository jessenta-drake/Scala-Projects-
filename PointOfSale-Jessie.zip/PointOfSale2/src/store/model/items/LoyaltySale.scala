package store.model.items

import store.model.checkout.{Checkout, Scan, moreFeatures}

class LoyaltySale(percentageOfSale:Double) extends Modifier {
  this.anotherState = new offState(this)
    this.perPer= percentageOfSale / 100.0
    ///var state: Modifier = new Checkout
    override def updatePrice(thePrice: Double): Double = {
      //val applyTo: Double = (thePrice * (1 - perPer))
      //applyTo
      this.anotherState.updatePrice(thePrice)
    }

    override def computeTax(theTax: Double): Double = {
      //0.0
      this.anotherState.computeTax(theTax)
    }
    override def switchStates():Unit={
      this.anotherState.switchStates()
    }


  }

