package store.model.items

import store.model.checkout.{Scan, moreFeatures}


class Item ( var oneDescription:String, var onePrice:Double){
  var togetherIG:List[Modifier]=List()
  var states: Modifier = new LoyaltySale(20.0)

  var newerPrice=0.0
  // TODO: Complete this class according to the features listed in the HW document

  def description(): String = {
    this.oneDescription
  }

  def price(): Double = {
    var originalPrice=onePrice
    for(modifiers<-togetherIG){
      originalPrice=modifiers.updatePrice(originalPrice)
    }
    originalPrice
  }

  def setBasePrice(x:Double) ={
    this.onePrice=x
  }

  def addModifier(addedMod:Modifier):Unit={
    togetherIG =togetherIG:+addedMod
  }

  def tax():Double={
    val withTax=price()
    var theTax=0.0
    for(modifiers<-togetherIG){
      theTax+=modifiers.computeTax(withTax)
    }
    theTax
  }


}

