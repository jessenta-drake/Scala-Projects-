package tests

import store.model.items.{BottleDeposit, Item, LoyaltySale, Modifier, Sale, SalesTax}
import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout

class ApplicationObjective extends FunSuite {
  test("test 1") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()
    val testModifier: Modifier = new LoyaltySale(20.0)
    val testItem: Item = new Item("banana", 1.00)
    testSelfCheckout1.addItemToStore("123", testItem)
    testItem.addModifier(testModifier)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()
    testSelfCheckout1.loyaltyCardPressed()

    //testSelfCheckout1.total()
    testSelfCheckout1.displayString()
    assert(testSelfCheckout1.displayString() == "cash or credit")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.total() - 2.40)) < 0.001, testSelfCheckout1.total())


      // TODO

    }

  test("test 2") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()
    //val testModifier: Modifier = new LoyaltySale(20.0)
    val testItem: Item = new Item("banana", 1.00)
    testSelfCheckout1.addItemToStore("123", testItem)
    //testItem.addModifier(testModifier)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()


    testSelfCheckout1.total()

    assert(testSelfCheckout1.displayString() == "cash or credit")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.total() - 3.00)) < 0.001)


    // TODO

  }

  test("test 3") {

    val testSelfCheckout1: SelfCheckout = new SelfCheckout()
    val testModifier: Modifier = new LoyaltySale(20.0)
    val testItem: Item = new Item("banana", 1.00)
    testItem.addModifier(testModifier)
    val testItem2: Item = new Item("strawberry", 2.00)
    testItem2.addModifier(testModifier)
    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()
    testSelfCheckout1.loyaltyCardPressed()
    testSelfCheckout1.cashPressed()

    //assert(testSelfCheckout1.itemsInCart().isEmpty)

    testSelfCheckout1.addItemToStore("234", testItem2)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.numberPressed(4)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()

    assert(testSelfCheckout1.displayString() == "cash or credit")
    val cart = testSelfCheckout1.itemsInCart()
    //assert(cart.head.description() == "strawberry")
    assert((Math.abs(testSelfCheckout1.total()-2.00))<0.001,testSelfCheckout1.total())





    // TODO

  }




  test("test 4") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()
    val testModifier: Modifier = new LoyaltySale(20.0)
    val testItem: Item = new Item("banana", 1.00)
    testSelfCheckout1.addItemToStore("123", testItem)
    testItem.addModifier(testModifier)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()
    testSelfCheckout1.loyaltyCardPressed()
    testSelfCheckout1.loyaltyCardPressed()

    testSelfCheckout1.total()

   // assert(testSelfCheckout1.displayString() == "cash or credit")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.total() - 2.40)) < 0.001, testSelfCheckout1.total())


    // TODO

  }

  test("test 5") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()
    val testModifier: Modifier = new LoyaltySale(20.0)
    val testItem: Item = new Item("banana", 1.00)
    testSelfCheckout1.addItemToStore("123", testItem)
    testItem.addModifier(testModifier)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()
    //testSelfCheckout1.loyaltyCardPressed()
    //testSelfCheckout1.loyaltyCardPressed()

    testSelfCheckout1.total()

    assert(testSelfCheckout1.displayString() == "cash or credit")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.total() - 3.00)) < 0.001,testSelfCheckout1.total())


    // TODO

  }
  test("test 6") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()
    val testModifier: Modifier = new LoyaltySale(20.0)
    val testModifier2: Modifier = new Sale(20.0)
    val testModifier3: Modifier = new SalesTax(8.0)
    val testModifier4: Modifier = new BottleDeposit(1.00)
    val testItem: Item = new Item("banana", 1.00)
    testSelfCheckout1.addItemToStore("123", testItem)
    testItem.addModifier(testModifier)
    testItem.addModifier(testModifier2)
    testItem.addModifier(testModifier3)
    testItem.addModifier(testModifier4)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    //testSelfCheckout1.enterPressed()
    //testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()
    testSelfCheckout1.loyaltyCardPressed()

    //testSelfCheckout1.total()
    testSelfCheckout1.displayString()
    assert(testSelfCheckout1.displayString() == "cash or credit")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.total() - 1.691)) < 0.001, testSelfCheckout1.total())


    // TODO

  }
  test("test 7") {

    val testSelfCheckout1: SelfCheckout = new SelfCheckout()
    val testModifier: Modifier = new LoyaltySale(20.0)
    val testItem: Item = new Item("banana", 1.00)
    testItem.addModifier(testModifier)
    val testItem2: Item = new Item("strawberry", 2.00)
    //testItem.addModifier(testModifier)
    testItem2.addModifier(testModifier)
    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()
    testSelfCheckout1.loyaltyCardPressed()
    testSelfCheckout1.cashPressed()

    assert(testSelfCheckout1.itemsInCart().isEmpty)

    testSelfCheckout1.addItemToStore("234", testItem2)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.numberPressed(4)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()
    testSelfCheckout1.loyaltyCardPressed()

    assert(testSelfCheckout1.displayString() == "cash or credit")
    val cart1 = testSelfCheckout1.itemsInCart()
    assert(cart1.head.description() == "strawberry")
    assert((Math.abs(testSelfCheckout1.total()-1.60))<0.001,testSelfCheckout1.total())





    // TODO

  }



  }

