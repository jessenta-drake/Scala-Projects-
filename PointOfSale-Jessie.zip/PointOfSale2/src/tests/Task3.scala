package tests

import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.{Item, Modifier, Sale}

class Task3 extends FunSuite{
  test("test 1") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)
    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()

    testSelfCheckout1.total()

    assert(testSelfCheckout1.displayString() == "")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.total()-3.00))<0.001)


    // TODO

  }

  test("test 2") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)
    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()

    testSelfCheckout1.total()

    assert(testSelfCheckout1.displayString() == "cash or credit")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.total()-3.00))<0.001)


    // TODO

  }

  test("test 3") {

    val testSelfCheckout1: SelfCheckout = new SelfCheckout()
    val testItem: Item = new Item("banana", 1.00)
    val testItem2: Item = new Item("strawberry", 2.00)
    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()
    testSelfCheckout1.cashPressed()

    assert(testSelfCheckout1.itemsInCart().isEmpty)

    testSelfCheckout1.addItemToStore("234", testItem2)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.numberPressed(4)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.checkoutPressed()

    assert(testSelfCheckout1.displayString() == "cash or credit")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "strawberry")
    assert((Math.abs(testSelfCheckout1.total()-2.00))<0.001)





    // TODO

  }

}