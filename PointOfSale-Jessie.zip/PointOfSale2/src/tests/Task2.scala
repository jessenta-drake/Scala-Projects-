package tests

import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.{BottleDeposit, Item, Modifier, Sale, SalesTax}


class Task2 extends FunSuite {
  test("test 1") {
    val testSelfCheckout4: SelfCheckout = new SelfCheckout()
    assert(testSelfCheckout4.displayString() == "")
    val testItem: Item = new Item("mango", 3.00)
    val testItem2: Item = new Item("melon", 10.00)
    val testItem3: Item = new Item("kiwi", 4.00)
    val testItem4: Item = new Item("banana", 1.00)

    testSelfCheckout4.addItemToStore("345", testItem)
    testSelfCheckout4.addItemToStore("0012", testItem2)
    testSelfCheckout4.addItemToStore("456", testItem3)
    testSelfCheckout4.addItemToStore("123", testItem4)
    testSelfCheckout4.numberPressed(3)
    testSelfCheckout4.numberPressed(4)
    testSelfCheckout4.numberPressed(5)
    assert(testSelfCheckout4.displayString() == "345")
    testSelfCheckout4.enterPressed()
    testItem.setBasePrice(4.00)
    testSelfCheckout4.numberPressed(0)
    testSelfCheckout4.numberPressed(0)
    testSelfCheckout4.numberPressed(1)
    testSelfCheckout4.numberPressed(2)
    testSelfCheckout4.enterPressed()
    testSelfCheckout4.numberPressed(4)
    testSelfCheckout4.numberPressed(5)
    testSelfCheckout4.numberPressed(6)
    testSelfCheckout4.enterPressed()
    testSelfCheckout4.addItemToStore("123", testItem)
    testSelfCheckout4.numberPressed(1)
    testSelfCheckout4.numberPressed(2)
    testSelfCheckout4.enterPressed()

    val cart = testSelfCheckout4.itemsInCart()
    assert(testSelfCheckout4.displayString() == "")
    assert(cart.head.description() == "mango")
    assert(Math.abs(cart.head.price()- 4.00) < 0.001)
    assert(cart(1).description() == "melon")
    assert(Math.abs(cart(1).price()- 10.00) < 0.001)
    assert(cart(2).description() == "kiwi")
    assert(Math.abs(cart(2).price()- 4.00) < 0.001)
    assert(cart(3).description() == "error")
    assert(Math.abs(cart(3).price()- 0.0) < 0.001)
    // TODO

  }


  test("test 2") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)
    val testModifier: Modifier = new Sale(20.0)

    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testItem.addModifier(testModifier)

    assert(testSelfCheckout1.displayString() == "")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert(Math.abs(cart.head.price()- .80) < 0.001)


    // TODO

  }
  test("test 3") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)
    val testModifier: Modifier = new SalesTax(8.0)


    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testItem.addModifier(testModifier)
    testSelfCheckout1.total()

    assert(testSelfCheckout1.displayString() == "")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert(Math.abs(testSelfCheckout1.total()- 1.08) < 0.001)


    // TODO

  }
  test("test 4") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)
    val testModifier1: Modifier = new BottleDeposit(0.05)

    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testItem.addModifier(testModifier1)
    testSelfCheckout1.total()

    assert(testSelfCheckout1.displayString() == "")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert(Math.abs(cart.head.price()+testItem.tax()- 1.05) < 0.001)


    // TODO

  }
  /*test("test 5") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)
    val testModifier1: Modifier = new BottleDeposit(0.05)
    val testModifier2: Modifier = new SalesTax(8.0)

    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testItem.addModifier(testModifier1)
    testSelfCheckout1.total()
    testItem.addModifier(testModifier2)
    testItem.tax()
    testSelfCheckout1.total()

    assert(testSelfCheckout1.displayString() == "")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert(Math.abs(cart.head.price() + testItem.tax() - 1.13) < 0.001)
  }*/
    test("test 5") {
      val testSelfCheckout1: SelfCheckout = new SelfCheckout()

      val testItem: Item = new Item("banana", 1.00)
      val testModifier: Modifier = new Sale(20.0)
      val testModifier2: Modifier = new SalesTax(8.0)
      val testModifier3: Modifier = new BottleDeposit(1.00)


      testSelfCheckout1.addItemToStore("123", testItem)
      testSelfCheckout1.numberPressed(1)
      testSelfCheckout1.numberPressed(2)
      testSelfCheckout1.numberPressed(3)
      testSelfCheckout1.enterPressed()
      testItem.addModifier(testModifier)
      testItem.addModifier(testModifier2)
      testItem.addModifier(testModifier3)
      testSelfCheckout1.total()





      assert(testSelfCheckout1.displayString() == "")
      val cart = testSelfCheckout1.itemsInCart()
      assert(cart.head.description() == "banana")
      assert(Math.abs(cart.head.price()- .80) < 0.001)


    // TODO

  }
  test("test 6") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)


    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testSelfCheckout1.subtotal()

    assert(testSelfCheckout1.displayString() == "")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.subtotal()-1.00))<0.001)


    // TODO

  }

  test("test 7") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)
    val testModifier2: Modifier = new SalesTax(8.0)

    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testItem.addModifier(testModifier2)
    testSelfCheckout1.tax()

    assert(testSelfCheckout1.displayString() == "")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.tax()-0.08))<0.001)


    // TODO

  }

  test("test 8") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)
    val testModifier0: Modifier = new Sale(10.0)
    val testModifier1: Modifier = new Sale(20.0)
    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()
    testItem.addModifier(testModifier0)
    testItem.addModifier(testModifier1)
    testSelfCheckout1.total()

    assert(testSelfCheckout1.displayString() == "")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert((Math.abs(testSelfCheckout1.total()-.72))<0.001)


    // TODO

  }



}
