package tests

import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.Item

class Task1 extends FunSuite {

  test("test 1") {
    val testSelfCheckout1: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)

    testSelfCheckout1.addItemToStore("123", testItem)
    testSelfCheckout1.numberPressed(1)
    testSelfCheckout1.numberPressed(2)
    testSelfCheckout1.numberPressed(3)
    testSelfCheckout1.enterPressed()

    assert(testSelfCheckout1.displayString() == "")
    val cart = testSelfCheckout1.itemsInCart()
    assert(cart.head.description() == "banana")
    assert(Math.abs(cart.head.price()- 1.00) < 0.001)


    // TODO

  }

  test("test 2") {
    val testSelfCheckout2: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("banana", 1.00)

    testSelfCheckout2.addItemToStore("123", testItem)
    testSelfCheckout2.numberPressed(1)
    testSelfCheckout2.numberPressed(2)
    testSelfCheckout2.enterPressed()

    assert(testSelfCheckout2.displayString() == "")
    val cart = testSelfCheckout2.itemsInCart()
    assert(cart.head.description() == "error")
    assert(Math.abs(cart.head.price()- 0.0) < 0.001)


    // TODO

  }


  test("test 3") {
    val testSelfCheckout2: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("strawberry", 2.00)

    testSelfCheckout2.addItemToStore("234", testItem)
    testSelfCheckout2.numberPressed(2)
    testSelfCheckout2.numberPressed(3)
    testSelfCheckout2.numberPressed(4)
    testSelfCheckout2.enterPressed()
    testItem.setBasePrice(4.00)

    assert(testSelfCheckout2.displayString() == "")
    val cart = testSelfCheckout2.itemsInCart()
    assert(cart.head.description() == "strawberry")
    assert(Math.abs(cart.head.price()- 4.00) < 0.001)


    // TODO

  }

  test("test 4") {
    val testSelfCheckout3: SelfCheckout = new SelfCheckout()

    val testItem: Item = new Item("mango", 3.00)

    testSelfCheckout3.addItemToStore("345", testItem)
    testSelfCheckout3.numberPressed(3)
    testSelfCheckout3.numberPressed(4)
    testSelfCheckout3.numberPressed(5)
    testSelfCheckout3.clearPressed()

    assert(testSelfCheckout3.displayString() == "")
    val cart = testSelfCheckout3.itemsInCart()
    assert(cart.isEmpty)



    // TODO

  }

  test("test 5") {
    val testSelfCheckout4: SelfCheckout = new SelfCheckout()
    assert(testSelfCheckout4.displayString() == "")
    val testItem: Item = new Item("mango", 3.00)
    val testItem2: Item = new Item("melon", 10.00)
    val testItem3: Item = new Item("kiwi", 4.00)

    testSelfCheckout4.addItemToStore("345", testItem)
    testSelfCheckout4.addItemToStore("0012", testItem2)
    testSelfCheckout4.addItemToStore("456", testItem3)
    testSelfCheckout4.numberPressed(3)
    testSelfCheckout4.numberPressed(4)
    testSelfCheckout4.numberPressed(5)
    assert(testSelfCheckout4.displayString() == "345")
    testSelfCheckout4.enterPressed()
    testSelfCheckout4.numberPressed(0)
    testSelfCheckout4.numberPressed(0)
    testSelfCheckout4.numberPressed(1)
    testSelfCheckout4.numberPressed(2)
    testSelfCheckout4.enterPressed()
    testSelfCheckout4.numberPressed(4)
    testSelfCheckout4.numberPressed(5)
    testSelfCheckout4.numberPressed(6)
    testSelfCheckout4.enterPressed()


    val cart = testSelfCheckout4.itemsInCart()
    assert(testSelfCheckout4.displayString() == "")
    assert(cart.head.description() == "mango")
    assert(Math.abs(cart.head.price()- 3.00) < 0.001)
    assert(cart(1).description() == "melon")
    assert(Math.abs(cart(1).price()- 10.00) < 0.001)
    assert(cart(2).description() == "kiwi")
    assert(Math.abs(cart(2).price()- 4.00) < 0.001)



    // TODO

  }

}
